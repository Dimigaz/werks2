package com.example.werks.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name="bookAuthors")
public class BookAuthor {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="author_id")
	private int authorid;

	@Column(name="name")
	private String name;
	
	@ManyToMany(mappedBy = "bookAuthors", cascade = CascadeType.ALL)
	private List<Book> books = new ArrayList<>();
	
	public int getAuthorid() {
		return authorid;
	}
	
	public String getName() {
		return name;
	}
	
	public List<Book> getBooks() {
		return books;
	}
	
	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	
}
