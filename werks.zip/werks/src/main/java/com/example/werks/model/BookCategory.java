package com.example.werks.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name="bookCategory")
public class BookCategory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="category_Id")
	private int categoryId;
	
	@Column(name="name")
	private String name;
	
	@ManyToMany(mappedBy = "bookCategory", cascade = CascadeType.ALL)
	private List<Book> books = new ArrayList<>();
	
	public int getCategoryId() {
		return categoryId;
	}
	
	public String getName() {
		return name;
	}
	
	public List<Book> getBooks() {
		return books;
	}
	
	public void setAuthorid(int categoryId) {
		this.categoryId = categoryId;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setBooks(List<Book> books) {
		this.books = books;
	}


}
