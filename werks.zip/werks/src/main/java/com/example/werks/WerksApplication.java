package com.example.werks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WerksApplication {

	public static void main(String[] args) {
		SpringApplication.run(WerksApplication.class, args);
	}

}
